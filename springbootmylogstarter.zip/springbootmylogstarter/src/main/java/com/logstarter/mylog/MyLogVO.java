package com.logstarter.mylog;

import java.util.Date;

/**
 * 自定义日志输出实体：定义日志的一些输出属性
 */
public class MyLogVO {

    private String className; //类名
    private String methodName; //方法名
    private String params;  //请求参数
    private String retVal;  //返回值
    private String model; // 操作模块
    private String optType;  // 操作类型
    private String description;  // 操作说明
    private String optUri; //请求URI
    private Date optTime; //操作时间点
    private String excName; //异常名称
    private String excInfo; //异常信息

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getOptType() {
        return optType;
    }

    public void setOptType(String optType) {
        this.optType = optType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getOptUri() {
        return optUri;
    }

    public void setOptUri(String optUri) {
        this.optUri = optUri;
    }

    public String getParams() {
        return params;
    }

    public void setParams(String params) {
        this.params = params;
    }

    public Date getOptTime() {
        return optTime;
    }

    public void setOptTime(Date optTime) {
        this.optTime = optTime;
    }

    public String getRetVal() {
        return retVal;
    }

    public void setRetVal(String retVal) {
        this.retVal = retVal;
    }

    public String getExcName() {
        return excName;
    }

    public void setExcName(String excName) {
        this.excName = excName;
    }

    public String getExcInfo() {
        return excInfo;
    }

    public void setExcInfo(String excInfo) {
        this.excInfo = excInfo;
    }

    @Override
    public String toString() {
        return "MyLogVO{" +
                "className='" + className + '\'' +
                ", methodName='" + methodName + '\'' +
                ", params='" + params + '\'' +
                ", retVal='" + retVal + '\'' +
                ", model='" + model + '\'' +
                ", optType='" + optType + '\'' +
                ", description='" + description + '\'' +
                ", optUri='" + optUri + '\'' +
                ", optTime=" + optTime +
                ", excName='" + excName + '\'' +
                ", excInfo='" + excInfo + '\'' +
                '}';
    }
}
