package com.logstarter.mylog;

import java.lang.annotation.*;

@Target(ElementType.METHOD)  //METHOD方法级别生效
@Retention(RetentionPolicy.RUNTIME)
@Documented
@Inherited
/**
 * 自定义日志注解
 */
public @interface MyLog {
    String model() default ""; // 操作模块
    String optType() default "";  // 操作类型
    String description() default "";  // 操作说明

}
