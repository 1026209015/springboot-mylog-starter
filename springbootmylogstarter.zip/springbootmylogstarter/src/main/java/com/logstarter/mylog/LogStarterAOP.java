package com.logstarter.mylog;

import com.alibaba.fastjson.JSON;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import javax.servlet.http.HttpServletRequest;
import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Aspect
@Component
/**
 * 自定义日志输出AOP切面，定义以添加了MyLog注解的所有方法作为连接点，
 * 这些连接点触发时定义对应正常方法返回时通知以及异常发生时通知
 */
public class LogStarterAOP {

    @Autowired
    private MyLogService myLogService;

    /**
     * 切点连接点：在MyLog注解的位置切入
     */
    @Pointcut("@annotation(com.logstarter.mylog.MyLog)")
    public void doMyLogCut() {
        System.out.println("start doMyLog...");
    }

    /**
     * MyLog注解方法执行返回后触发，记录参数等信息。
     * @param joinPoint
     * @param keys
     */
    @AfterReturning(value = "doMyLogCut()", returning = "keys")
    public void showMyLog(JoinPoint joinPoint, Object keys) {
        MyLogVO myLogVO = this.getMyLog(joinPoint, keys, null);
        myLogService.showLog(myLogVO);
    }

    /**
     * 异常发生时的通知
     * @param joinPoint
     * @param e
     */
    @AfterThrowing(pointcut = "doMyLogCut()", throwing = "e")
    public void doExceptionMyLog(JoinPoint joinPoint, Throwable e) {
        MyLogVO myLogVO = this.getMyLog(joinPoint, null, e);
        myLogService.showLog(myLogVO);
    }

    /**
     * 获取输出日志实体
     * @param joinPoint 触发的连接点
     * @param keys 返回值
     * @param e 异常对象
     * @return MyLogVO
     */
    private MyLogVO getMyLog(JoinPoint joinPoint, Object keys, Throwable e){
        // 获取RequestAttributes
        RequestAttributes requestAttributes = RequestContextHolder.getRequestAttributes();
        // 从获取RequestAttributes中获取HttpServletRequest的信息
        HttpServletRequest request = (HttpServletRequest) requestAttributes
                .resolveReference(RequestAttributes.REFERENCE_REQUEST);
        // 输出日志VO
        MyLogVO myLogVO = new MyLogVO();
        try {
            // 从切面织入点处通过反射机制获取织入点处的方法
            MethodSignature signature = (MethodSignature) joinPoint.getSignature();
            // 获取切入点所在的方法
            Method method = signature.getMethod();
            // 获取操作
            MyLog opLog = method.getAnnotation(MyLog.class);
            if (opLog != null) {
                myLogVO.setModel(opLog.model());
                myLogVO.setOptType(opLog.optType());
                myLogVO.setDescription(opLog.description());
            }
            // 获取请求的类名
            String className = joinPoint.getTarget().getClass().getName();
            myLogVO.setClassName(className);
            // 获取请求的方法名
            String methodName = method.getName();
            myLogVO.setMethodName(methodName);

            //请求uri
            String uri = request.getRequestURI();
            myLogVO.setOptUri(uri);

            //操作时间点
            myLogVO.setOptTime(new Date());

            //异常名称+异常信息
            if(null != e){
                myLogVO.setExcName(e.getClass().getName());
                myLogVO.setExcInfo(stackTraceToString(e.getClass().getName(), e.getMessage(), e.getStackTrace()));
            }

            //请求的参数，参数所在的数组转换成json
            Map<String, String> rtnMap = converMap(request.getParameterMap());
            String params = JSON.toJSONString(rtnMap);
            myLogVO.setParams(params);

            //返回值
            if(null != keys && Void.class.getName() != keys){
                myLogVO.setRetVal(keys.toString());
            }

            //输出日志
            myLogService.showLog(myLogVO);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return myLogVO;
    }


    /**
     * 转换request 请求参数
     * @param paramMap
     * @return
     */
    private Map<String, String> converMap(Map<String, String[]> paramMap) {
        Map<String, String> rtnMap = new HashMap<String, String>();
        for (String key : paramMap.keySet()) {
            rtnMap.put(key, paramMap.get(key)[0]);
        }
        return rtnMap;
    }

    /**
     * 转换异常信息为字符串
     * @param exceptionName
     * @param exceptionMessage
     * @param elements
     * @return
     */
    private String stackTraceToString(String exceptionName, String exceptionMessage, StackTraceElement[] elements) {
        StringBuffer strbuff = new StringBuffer();
        for (StackTraceElement stet : elements) {
            strbuff.append(stet + "\n");
        }
        String message = exceptionName + ":" + exceptionMessage + "\n\t" + strbuff.toString();
        return message;
    }

}
