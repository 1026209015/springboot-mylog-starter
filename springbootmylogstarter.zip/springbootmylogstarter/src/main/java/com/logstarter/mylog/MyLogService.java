package com.logstarter.mylog;

import org.springframework.stereotype.Component;

/**
 * 日志操作Service
 */
@Component
public class MyLogService {

    /**
     * 日志记录
     */
    public void showLog(MyLogVO myLogVO){
        System.out.println(myLogVO);
    }

}
